Introduction
KDD Cup 1998: Direct marketing for profit optimization

The competition task is a regression problem where the goal is to estimate the return from a direct mailing in order to maximize donation profits.

http://www.kdd.org/kdd-cup/view/kdd-cup-1998/Intro
